// استيراد مكتبة express
const express = require('express');
const app = express();
const cors = require('cors');
const { createTables } = require('./database');
const candidatesRoutes = require('./Routes/candidates/candidates');
const avancesRoutes = require('./Routes/avances');
const drave = require('./Routes/draveng');
const responsables = require('./Routes/responsables');
const nomeschool = require('./Routes/nomschool');
const monitor = require('./Routes/monitor');
const List_of_drivers = require('./Routes/List_of_drivers');
const financier_de_letablissement = require('./Routes/financier_de_letablissement');
const getpdf = require('./Routes/getpdf');
const driversRoutes = require('./Routes/drivers');
const updateinfo = require('./Routes/candidates/putcandidates');
const getallcandidates = require('./Routes/candidates/getallcandidates');
const addConduire = require('./Routes/candidates/addConduire');
const getConduire = require('./Routes/candidates/getConduire');
const resetpassword = require('./Routes/candidates/resetpassword');
const loginuser = require('./Routes/candidates/loginuser')
require('./cronJob');
require('./changestate')
app.use((req, res, next) => {
    res.setHeader("Content-Security-Policy", "default-src 'self'; connect-src 'self' http://localhost:3000 http://localhost:5173;");

    next();
  });
// تعريف المنفذ
const port = 3000;
app.use(express.json());
app.use(cors({
    origin: 'http://localhost:5173', // Allow only your React app's domain
  }));

  
  

// استجابة بسيطة عند طلب الصفحة الرئيسية
app.get('/', (req, res) => {
  res.send('مرحبًا بك في خادم Node.js!');
});








app.use('/candidates', candidatesRoutes);
app.use('/candidates', updateinfo);
app.use('/candidates', getallcandidates);
app.use('/avances', avancesRoutes);
app.use('/draveng', drave);
app.use('/responsables', responsables);
app.use('/nomeschool', nomeschool);
app.use('/monitor', monitor);
app.use('/listofdriive', List_of_drivers);
app.use('/financier', financier_de_letablissement);
app.use('/getpdf', getpdf);
app.use('/api', driversRoutes);
app.use('/candidates', resetpassword);
app.use('/candidates', loginuser);

// تشغيل الخادم باستخدام app.listen
app.listen(port, () => {
  console.log(`http://localhost:${port}`);
});
// بدء الخادم وإنشاء الجداول
(async () => {
    await createTables();
  })();
