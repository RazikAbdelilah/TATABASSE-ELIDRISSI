const cron = require('node-cron');
const { pool } = require('./database');

cron.schedule('0 0 * * *', async () => {
  console.log('Running state update task...');
  const connection = await pool.getConnection();

  try {
    const [results] = await connection.execute(`
      SELECT 
        c.id, c.state, c.paiment_total_necessair, 
        a.montant, a.date AS last_payment_date,
        c.intervale1, c.intervale2, c.intervale3, c.intervale4
      FROM candidates c
      LEFT JOIN avances a ON c.id = a.candidate_id
      WHERE a.date = (SELECT MAX(date) FROM avances WHERE candidate_id = c.id) -- جلب آخر دفعة فقط
    `);

    const today = new Date();

    for (const result of results) {
      try {
        const { 
          id, state, paiment_total_necessair, 
          montant, last_payment_date, 
          intervale1, intervale2, intervale3, intervale4 
        } = result;

        const lastPaymentDate = last_payment_date ? new Date(last_payment_date) : null;
        const daysDiff = lastPaymentDate 
          ? Math.floor((today - lastPaymentDate) / (1000 * 60 * 60 * 24)) 
          : null;

        let newState = state;

        // التحقق إذا كانت الدفعة الأخيرة قد وصلت المبلغ المتفق عليه
        if (montant >= paiment_total_necessair) {
          newState = 'Completed';
        }
        // الشروط الحالية بناءً على الفرق بين التواريخ
        else if (daysDiff !== null && daysDiff < intervale1 && montant <= 200) {
          newState = 'Bon';
        } else if (daysDiff !== null && daysDiff >= intervale1 && montant <= 200) {
          newState = 'Pasbon';
        } else if (daysDiff !== null && daysDiff < intervale2 && montant > 200 && montant <= 450) {
          newState = 'Bon';
        } else if (daysDiff !== null && daysDiff >= intervale2 && montant > 200 && montant <= 450) {
          newState = 'Pasbon';
        } else if (daysDiff !== null && daysDiff < intervale3 && montant > 450 && montant <= 900) {
          newState = 'Bon';
        } else if (daysDiff !== null && daysDiff >= intervale3 && montant > 450 && montant <= 900) {
          newState = 'Pasbon';
        } else if (daysDiff !== null && daysDiff < intervale4 && montant > 900 && montant <= 1999) {
          newState = 'Bon';
        } else if (daysDiff !== null && daysDiff >= intervale4 && montant > 900 && montant <= 1999) {
          newState = 'Pasbon';
        }

        // تحديث الحالة في قاعدة البيانات إذا تغيرت
        if (newState !== state) {
          await connection.execute(`
            UPDATE candidates 
            SET state = ? 
            WHERE id = ?
          `, [newState, id]);

          console.log(`Candidate ID: ${id} state updated to: ${newState}`);
        }
      } catch (err) {
        console.error(`Error processing candidate ID: ${result.id}, Error: ${err.message}`);
      }
    }

    console.log('State update task completed');
  } catch (err) {
    console.error('Error updating states:', err.message);
  } finally {
    connection.release();
  }
});
